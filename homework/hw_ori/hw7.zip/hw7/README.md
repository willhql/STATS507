## Files to be included in release 

- hw7.ipynb 
- SkypeIRC.txt
- Chinook_Sqlite.sqlite